#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <time.h>
#include <string.h>



typedef struct node // struktura
{
    char *pNumRej;
    time_t entryTime;
    struct node *pNext;
} node;

int main(void)
{
    node* create_node();

    void removeCar(char *pNumRej, node *head);
    //List* initList();

    node *par1, *par2 = NULL;
    par1 = create_node(); // par1 (wskaznik listy, glowa)

    //do zrobienia na potem
    par2 = create_node();


    //initList(); //Inicjalizujemy liste

    printf("Number of elements: %d\n", getNumOfCars(par1));

    //removeCar("EL020GM", par1); // dostawiona

    addCar("EL020GM", par1);
    printf("Number of elements: %d REJ: %s \n", getNumOfCars(par1) );
    addCar("WY020GM", par1);
    printf("Number of elements: %d\n", getNumOfCars(par1));
    addCar("NA020GM", par1);
    printf("Number of elements: %d\n", getNumOfCars(par1));
    removeCar("WY020GM", par1);
    printf("Number of elements: %d\n", getNumOfCars(par1));
    addCar("RZ020GM", par1);
    printf("Number of elements: %d\n", getNumOfCars(par1));
    removeCar("EL020GM", par1);
    printf("Number of elements: %d\n", getNumOfCars(par1));

    deinitList(par1);// Deinicjalizacja listy

    free(par1->pNext);
    free(par1->pNumRej);
    free(par1);
    return 0;
}

node* create_node()
{
    node* head = NULL;
    head = malloc(sizeof(node));
    head->pNumRej = malloc(strlen("Root") + 1u);
    strcpy(head->pNumRej, "Root");
    time(&(head->entryTime));
    head->pNext=NULL;
    return head;

}


void deinitList(node *par1) //deinicjalizacja listy
{
    node *curr = NULL;
    node *temp = NULL;

    if (par1->pNext != NULL)
    {
        curr = par1->pNext;
        temp = curr;

        while(curr->pNext != NULL)
    {
        temp = curr->pNext;
        free(curr);
        free(curr->pNumRej);
        curr = temp;
    }
    }
    else printf("Lista jest pusta \n");

}

void addCar(char *pNumRej, node *head)
{
    node *pLastElement = head;
    node *pNewElement = NULL;




    while(pLastElement->pNext != NULL)
    {
        pLastElement = pLastElement->pNext;
    }


    pNewElement = malloc(sizeof(*pNewElement));
    pNewElement->pNumRej = malloc(strlen(pNumRej) + 1u);
    strcpy(pNewElement->pNumRej, pNumRej);
    time(&(pNewElement->entryTime));
    pNewElement->pNext = NULL;
    pLastElement->pNext = pNewElement;
}

int getNumOfCars(head)
{
    int size = 0;
    node *pLastElement = head;
    while(pLastElement->pNext != NULL)
    {
        pLastElement = (pLastElement->pNext);
        size ++;
    }
    return size;
}


void removeCar(char *pNumRej,node *head) //usuinięcie samochodu
{
    bool elementFound = 0;
    node *pIterElementBefre = NULL;
    node *pIterElement = head;
    node *pIterElementAfter = head->pNext;

    while((NULL != pIterElement) && (false == elementFound))
    {
        if(0 != strstr(pIterElement->pNumRej, pNumRej))
        {
            elementFound = true;
        }
        else
        {
            if(NULL != pIterElement->pNext)
            {
                pIterElementBefre = pIterElement;
                if(NULL != pIterElement->pNext)
                    pIterElementAfter = (pIterElement->pNext->pNext);
                else
                    pIterElementAfter = NULL;
                pIterElement = (pIterElement->pNext);
            }
        }
    }
    if(true == elementFound) //element znaleziony
    {
        if(NULL == pIterElementAfter)
        {
            pIterElementBefre->pNext=NULL;
        }
        else
        {
            pIterElementBefre->pNext=pIterElementAfter;
        }
        free(pIterElement->pNumRej);
        free(pIterElement);
    }
}
